/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.prueba;

import java.util.Scanner;
import paquete.clases.*;
import paquete.gestion.GestionJuego;

/**
 *
 * @author KONAHA
 */
public class prueba {
    public static void menu(GestionJuego objGE)
    {
        System.out.println("║"+"\033[42m"+" BIENVENIDO AL JUEGO DE PALABRAS "+"\u001B[0m"+"║");   
        System.out.println("║1-Nivel Fácil                    ║"
                +"\n║2-Nivel Medio                    ║"
                +"\n║3-Nivel Difícil                  ║"
                +"\n║4-Ver Historial                  ║"
                +"\n║5-Ver Leaderboards               ║"
                +"\n║0-Salir                          ║\n");
        System.out.println("################################");
        System.out.println("Elija una opción para continuar: ");
        System.out.println("################################");
        

        Scanner sc= new Scanner(System.in);
        int opcion=1;
        
        while (opcion>0)
        {
            opcion=sc.nextInt();

                if(opcion==1)
                {                      
                    Nivel_Facil objF= new Nivel_Facil(); 
                    objF.pedirnombre();
                    objF.ejecutar();
                    objGE.Ingresar(objF);
                    objGE.Leader_Facil(objF);
                    opcion=0;
                    menu(objGE);
                }
                else if(opcion==2)
                { 
                    Nivel_Medio objM= new Nivel_Medio(); 
                    objM.pedirnombre();
                    objM.IniciarTiempo();
                    objM.ejecutar();
                    objM.terminartiempo();
                    objGE.Ingresar(objM);
                    objGE.Leader_Medio(objM);
                    opcion=0;
                    menu(objGE);
                }
                else if(opcion==3)
                { 
                    Nivel_Dificil objH = new Nivel_Dificil();
                    objH.pedirnombre();
                    objH.IniciarTiempo();
                    objH.ejecutar();
                    objH.terminartiempo();
                    objGE.Ingresar(objH);  
                    objGE.Leader_Dificil(objH);
                    opcion=0;
                    menu(objGE);
                }
                else if(opcion==4)
                { 
                    System.out.println(objGE.VerInfo());
                    opcion=0;
                    menu(objGE);
                }
                else if(opcion==5)
                { 
                    int op=2;
                    while(op==2)
                    {
                        System.out.println("║\t"+"\033[42m"+" QUE NIVEL DESEA VER? "+"\u001B[0m"+"\t         ║");   
                        System.out.println("║1-Leaderboard Fácil                    ║"
                        +"\n║2-Leaderboard Medio                    ║"
                        +"\n║3-Leaderboard Difícil                  ║"
                        +"\n║0-Volver al menú                       ║\n");
                        System.out.println("################################");
                        System.out.println("Elija una opción para continuar: ");
                        System.out.println("################################");
                        int opcion_2=sc.nextInt();
                        if(opcion_2==1)
                        {
                            System.out.println(objGE.VerLeaderboardFacil());
                            op=2;
                        }
                        else if (opcion_2==2)
                        {
                            System.out.println(objGE.VerLeaderboardMedio());
                            op=2;
                        }
                        else if (opcion_2==3)
                        {
                            System.out.println(objGE.VerLeaderboardDificil());
                            op=2;
                        }
                        else if(opcion_2==0)
                        {
                            menu(objGE);
                            op=0;
                            opcion=0; 
                        }     
                        else
                        {
                            System.out.println("Función no disponible!");
                            op=2;
                        }    

                    } 

                }

                else if(opcion==0)
                {    
                    System.out.println("Gracias por su preferencia"+"\nVuelva pronto!");
                    opcion=0;
                    break;
                }  
                else
                {
                    System.out.println("Ingrese una opción válida!!");
                    System.out.println("Elija una opción para continuar: ");
                    opcion=100;
                }   

        }        

    }

  
    
    public static void main(String[] args) {
        GestionJuego objGE = new GestionJuego();
        menu(objGE);

    }
}
