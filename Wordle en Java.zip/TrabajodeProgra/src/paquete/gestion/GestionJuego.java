/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.gestion;

import paquete.clases.*;

/**
 *
 * @author KONAHA
 */
public class GestionJuego {
    private Juego[] arreglo;
    private Juego[] arreglofacil;
    private Juego[] arreglomedio;
    private Juego[] arreglodificil;
    int conta;
    int contaF;
    int contaM;
    int contaD;
   
    
    public GestionJuego() {
        arreglo = new Juego[100];
        arreglofacil = new Juego[100];
        arreglomedio = new Juego[100];
        arreglodificil = new Juego[100];
        conta=0;
        contaF=0;
        contaM=0;
        contaD=0;
    }

    public GestionJuego(Juego[] arreglo, int conta) {
        this.arreglo = arreglo;
        this.conta = conta;
    }

    public void Ingresar(Juego ref)
    {
        if (conta<arreglo.length)
        {
            arreglo[conta]=ref;
            conta++;       
        }
        else
        {
            System.out.println("No hay espacio!");
        }
    }
    
    public void Leader_Facil(Nivel_Facil ref)
    {        
        if (contaF<arreglofacil.length)
        {
            arreglofacil[contaF] = ref;
            contaF++;       
        }
        else
        {
            System.out.println("No hay espacio!");
        }
        
        Juego aux;

        for(int i=0;i<contaF-1;i++)
        {
            for(int j=0;j<contaF-1;j++)
            {
                if(arreglofacil[j].getIntento()>arreglofacil[j+1].getIntento())
                {
                    aux = arreglofacil[j];
                    arreglofacil[j] = arreglofacil[j+1];
                    arreglofacil[j+1] = aux;   
                }
            }
        } 



    }
    
    public String VerLeaderboardFacil()
    {
        int numjuego=1;
        String cad="";
        if(contaF>0)
        {
            for(int i=0;i<contaF;i++)
            {
                cad= cad+"\nLA POSICION N°"+numjuego+" ES:"
                +"\n##########################\n"
                +arreglofacil[i].VerInfo()
                +"\n##########################\n";
                numjuego++;
            }

        }
        else
        {
            cad="No hay Juegos realizados!\n\n\n\n";
        }
        return cad;
    }
    
    public void Leader_Medio(Nivel_Medio ref)
    {        
        if (contaM<arreglomedio.length)
        {
            arreglomedio[contaM] = ref;
            contaM++;       
        }
        else
        {
            System.out.println("No hay espacio!");
        }
        
        Juego aux;
        for(int i=0;i<contaM-1;i++)
        {
            for(int j=0;j<contaM-1;j++)
            {
                if(arreglomedio[j].getIntento()>arreglomedio[j+1].getIntento())
                {
                    aux = arreglomedio[j];
                    arreglomedio[j] = arreglomedio[j+1];
                    arreglomedio[j+1] = aux;   
                }
            }
        }
    }
    
    public String VerLeaderboardMedio()
    {
        int numjuego=1;
        String cad="";
        if(contaM>0)
        {
            for(int i=0;i<contaM;i++)
            {
                cad= cad+"\nLA POSICION N°"+numjuego+" ES:"
                +"\n##########################\n"
                +arreglomedio[i].VerInfo()
                +"\n##########################\n";
                numjuego++;
            }

        }
        else
        {
            cad="No hay Juegos realizados!\n\n\n\n";
        }
        return cad;
    }
    
     public void Leader_Dificil(Nivel_Dificil ref)
    {        
        if (contaD<arreglodificil.length)
        {
            arreglodificil[contaD] = ref;
            contaD++;       
        }
        else
        {
            System.out.println("No hay espacio!");
        }
        
        Juego aux;
        for(int i=0;i<contaD-1;i++)
        {
            for(int j=0;j<contaD-1;j++)
            {
                if(arreglodificil[j].getIntento()>arreglodificil[j+1].getIntento())
                {
                    aux = arreglodificil[j];
                    arreglodificil[j] = arreglodificil[j+1];
                    arreglodificil[j+1] = aux;   
                }
            }
        }
    }
    
    public String VerLeaderboardDificil()
    {
        int numjuego=1;
        String cad="";
        if(contaD>0)
        {
            for(int i=0;i<contaD;i++)
            {
                cad= cad+"\nLA POSICION N°"+numjuego+" ES:"
                +"\n##########################\n"
                +arreglodificil[i].VerInfo()
                +"\n##########################\n";
                numjuego++;
            }
        }
        else
        {
            cad="No hay Juegos realizados!\n\n\n\n";
        }
        return cad;
    }
    
    public String VerInfo()
    {
        int numjuego=1;
        String cad="";
        if(conta>0)
        {
            for(int i=0;i<conta;i++)
            {
                cad= cad+"\nJUEGO N°"+numjuego
                +"\n##########################\n"
                +arreglo[i].VerInfo()
                +"\n##########################\n";
                numjuego++;
            }

        }
        else
        {
            cad="No hay Juegos realizados!\n\n\n\n";
        }

        return cad;
    }
    
}

