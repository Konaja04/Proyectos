/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author KONAHA
 */
public abstract class Juego {
    protected String Paljuego,PalIngresa,nivel,Nombre;
    protected String b = "\u001B[0m"; //borrar
    protected String fVerde = "\033[42m";
    protected String fAmarillo = "\033[43m";
    protected String fGris = "\033[47m";
    protected String lverde = "\u001B[32m";
    protected String lrojo = "\u001B[31m";
    protected String [][] matriz;
    protected ArrayList<String> palabraaux; 
    protected boolean gano;
    protected int intento,conta_2;
   
    public Juego() {
        palabraaux= new ArrayList<String>();
        
    }

    public String getPaljuego() {
        return Paljuego;
    }

    public void setPaljuego(String Paljuego) {
        this.Paljuego = Paljuego;
    }

    public String getPalIngresa() {
        return PalIngresa;
    }

    public void setPalIngresa(String PalIngresa) {
        this.PalIngresa = PalIngresa;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(String[][] matriz) {
        this.matriz = matriz;
    }

    public ArrayList<String> getPalabraaux() {
        return palabraaux;
    }

    public void setPalabraaux(ArrayList<String> palabraaux) {
        this.palabraaux = palabraaux;
    }

    public boolean isGano() {
        return gano;
    }

    public void setGano(boolean gano) {
        this.gano = gano;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public int getIntento() {
        return intento;
    }

    public void setIntento(int intento) {
        this.intento = intento;
    }

    public int getConta_2() {
        return conta_2;
    }

    public void setConta_2(int conta_2) {
        this.conta_2 = conta_2;
    }


 
    public void pedirnombre()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa tu nombre: ");
        this.Nombre = sc.next();
        System.out.println("\n\n\n\n\n\n\n\n\n################################");
        System.out.println("Hola " + this.Nombre+"!");
    }
    
    public abstract void ejecutar();
    public abstract String colorear(String letra, String color);
    public abstract void ImpMatriz();
    public abstract void IngMatriz(String ref);

    public String VerInfo() {
        return "Nombre de Jugador: " + Nombre 
                + "\nNivel de Juego: "+this.nivel
                +"\nPalabra de juego: " + Paljuego 
                + "\nGanó: " + gano 
                + "\nN° de intentos: " + (intento+1)
                ;
    }
    

}
