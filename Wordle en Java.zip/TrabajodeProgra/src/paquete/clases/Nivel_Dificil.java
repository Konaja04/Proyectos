/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
/**
 *
 * @author LORD
 */
public class Nivel_Dificil extends Juego implements ITiempo
{
 
    private String timer;
    private int segundos=30;
    private int minutos=1;
    
    Timer tiempo = new Timer();
    TimerTask task = new TimerTask()
      {
        @Override
        public void run()
            {
                segundos--;
   
                if(segundos == 0)
                {
                minutos --;
                segundos = 59;
                } 
                if(minutos == 0)
                {
                    minutos = 0;
                }
            }    
      };
    
    @Override
    public void IniciarTiempo() 
    {
        tiempo.scheduleAtFixedRate(task, 1000, 1000);  
    }

    
    @Override
    public void terminartiempo() 
    {
        System.out.println ("Tiempo restante: " +(minutos<=9?"0":"")+minutos+":"+(segundos <= 9?"0":"")+segundos);
        timer= (minutos<=9?"0":"")+minutos+":"+(segundos <= 9?"0":"")+segundos;
        tiempo.cancel();
        
    }
    

    public Nivel_Dificil() 
    {
        Random rand = new Random();
        String[] ListaPals= {"CAMISA","VENTAS","GATITO","TREBOL"};
        this.Paljuego = ListaPals[rand.nextInt(ListaPals.length)];
        matriz = new String[6][6];
        this.nivel="Dificil";
    }
    @Override
    public void ejecutar() 
    {
        for(int i=0;i<6;i++)
        {
            palabraaux.add("-");
        }
            
        intento=0;
        Scanner sc= new Scanner(System.in);
        System.out.println("Bienvenido al nivel Dificil");
        System.out.println("Ingrese una palabra de 6 digitos:\n"
                + " 🚫  🚫  🚫  🚫  🚫  🚫\n" 
                + " 🚫  🚫  🚫  🚫  🚫  🚫\n"
                + " 🚫  🚫  🚫  🚫  🚫  🚫\n"
                + " 🚫  🚫  🚫  🚫  🚫  🚫\n"
                + " 🚫  🚫  🚫  🚫  🚫  🚫\n"
                + " 🚫  🚫  🚫  🚫  🚫  🚫\n");

        gano = false;
        
        while(gano!=true && intento < 6)
        {
            //Este for llena el arreglo con la palabra de juego para usarse más adelante
            for(int i=0;i<6;i++)
            {
                palabraaux.set(i,this.Paljuego.substring(i, i+1));
            } 
            PalIngresa=sc.next();
            while(PalIngresa.length()!=6)
            {
                System.out.println("Tiene que ser de 6 digitos");
                PalIngresa = sc.next();
            }
            //Si la palabra coincide con la del juego, se pinta de verde y ganas
            if (PalIngresa.equalsIgnoreCase(this.Paljuego))
            {
                PalIngresa = PalIngresa.toUpperCase();
                conta_2 = 0;
                for (int i=0; i<6;i++)
                {
                    IngMatriz(colorear(PalIngresa.substring(i,i+1),fVerde));
                    conta_2++;
                }                
                this.gano = true;
                ImpMatriz();
                System.out.println("\n" + lverde +"   ¡GANASTE!\n\n" + b);
                break;              
            }
            //Caso contrario, comparará bit a bit para saber cual colorear
            else
            {
                PalIngresa = PalIngresa.toUpperCase();
                conta_2 = 0;//Este contador es para que al llenar la matriz, esta se reinicie (a 0) cada vez que se ingrese una palabra nueva
                //Este for quita las letras que coinciden con las del arreglo
                for(int i=0;i<6;i++)
                {
                    if(this.palabraaux.get(i).equals(this.PalIngresa.substring(i, i+1)))
                    {
                        this.palabraaux.set(i,"-"); //set es igual a reemplazar | add es igual a añadir
                    }
                }

                //Acá iniciamos la comparación de bit a bit entre la palabra de juego y la ingresada.
                for(int i=0;i<6;i++)
                {
                    //Si la primera letra de la palabra ingresada coincide con la primera 
                    //del juego, esta se pinta de verde
                    if(PalIngresa.subSequence(i, i+1).equals(Paljuego.subSequence(i, i+1)))
                    {
                        IngMatriz(colorear(PalIngresa.substring(i, i+1),fVerde));
                        //el contador se suma uno pq ya recorrió una letra
                        conta_2++; 
                    }
                    //Si la palabra contiene la letra pero no está en el lugar exacto entra a una segunda condición
                    else if(Paljuego.contains(PalIngresa.subSequence(i, i+1)))
                    {
                        //Si el arreglo contiene la letra, quiere decir que aun se puede pintar de amarillo
                        if(palabraaux.contains(PalIngresa.subSequence(i, i+1)))
                        {
                            for(int j=0;j<6;j++)
                            {
                                if(this.palabraaux.get(j).equals(this.PalIngresa.substring(i, i+1)))
                                {
                                    this.palabraaux.set(j,"-"); //set es igual a reemplazar | add es igual a añadir
                                }
                            }             
                            IngMatriz(colorear(PalIngresa.substring(i, i+1),fAmarillo));
                        }
                        //Caso contrario, el arreglo no contiene la letra, es decir que ya no puede pintar la letra de amarillo
                        else
                        {
                            IngMatriz(colorear(PalIngresa.substring(i, i+1),fGris));
                        }
                        //el contador se suma uno pq ya recorrió una letra
                        conta_2++;
                    }
                    //Caso contrario, se pinta de gris
                    else
                    {
                        IngMatriz(colorear(PalIngresa.substring(i,i+1),fGris));
                        //el contador se suma uno pq ya recorrió una letra
                        conta_2++;                        
                    } 
                }    
            }    
        //imprimimos matriz
        ImpMatriz(); 
        //Verificamos numero de intentos
        if(intento==5)
        {
            System.out.println("\n" + lrojo + "  ¡PERDISTE!\n\n"+ b);
            break;
        }
        else
        {
            System.out.println("Intente con otra palabra: ");
            intento++;
        }
        }
    }

    
    @Override
    public void IngMatriz(String ref) 
    {
        for(int i=0;i<6;i++)
        {
            for(int j=0;j<6;j++)
            {
                if(i==intento)
                {
                    matriz[i][conta_2]= b+" "+ref+b+" ";
                }
                else if(i>intento)
                {
                    matriz[i][j]=" 🚫 ";
                }
            }
        }
    }
  

    @Override
    public String colorear(String letra, String color) 
    {
        return color+letra;
    }
    
    
    @Override
    public void ImpMatriz() 
    {
        String cad="";
        for (int i=0; i<6;i++)
        {
            for(int j=0; j<6;j++)
            {
                cad=cad+matriz[i][j];
            }
            System.out.println(cad);
            cad="";      
        }
    }

    @Override
    public String VerInfo() {
        return super.VerInfo()+ "\nTiempo restante: "+ timer
                ;
    }
    
    
    
    
    
}
